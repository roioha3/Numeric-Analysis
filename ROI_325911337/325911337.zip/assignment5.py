"""
In this assignment you should fit a model function of your choice to data 
that you sample from a contour of given shape. Then you should calculate
the area of that shape. 

The sampled data is very noisy so you should minimize the mean least squares 
between the model you fit and the data points you sample.  

During the testing of this assignment running time will be constrained. You
receive the maximal running time as an argument for the fitting method. You 
must make sure that the fitting function returns at most 5 seconds after the 
allowed running time elapses. If you know that your iterations may take more 
than 1-2 seconds break out of any optimization loops you have ahead of time.

Note: You are allowed to use any numeric optimization libraries and tools you want
for solving this assignment. 
Note: !!!Despite previous note, using reflection to check for the parameters 
of the sampled function is considered cheating!!! You are only allowed to 
get (x,y) points from the given shape by calling sample(). 
"""


import numpy as np
import time
from functionUtils import AbstractShape


import numpy as np
import time
from functionUtils import AbstractShape


class MyShape(AbstractShape):
    def __init__(self, points):
        self._points = np.array(points, dtype=np.float32)
        if len(self._points) < 3:
            self._points = np.array([[0, 0], [1, 0], [0.5, 1]], dtype=np.float32)
        self._n = len(self._points)
        self._compute_properties()

    def _compute_properties(self):
        diff = np.roll(self._points, -1, axis=0) - self._points
        self._segment_lengths = np.linalg.norm(diff, axis=1)
        self._total_perimeter = float(np.sum(self._segment_lengths))
        self._cumulative_lengths = np.zeros(self._n + 1, dtype=np.float32)
        self._cumulative_lengths[1:] = np.cumsum(self._segment_lengths, dtype=np.float32)

    def sample(self):
        if self._total_perimeter <= 0:
            p = self._points[0]
            return float(p[0]), float(p[1])

        rand_length = np.random.random() * self._total_perimeter
        segment_idx = int(np.searchsorted(self._cumulative_lengths[1:], rand_length))
        if segment_idx >= self._n:
            segment_idx = self._n - 1

        seg_len = self._segment_lengths[segment_idx]
        seg_start = self._cumulative_lengths[segment_idx]
        t = 0.0 if seg_len <= 1e-12 else (rand_length - seg_start) / seg_len
        t = float(np.clip(t, 0.0, 1.0))

        p1 = self._points[segment_idx]
        p2 = self._points[(segment_idx + 1) % self._n]
        p = p1 + t * (p2 - p1)
        return float(p[0]), float(p[1])

    def contour(self, n: int):
        if n <= 0:
            return np.zeros((0, 2), dtype=np.float32)
        if self._total_perimeter <= 1e-12:
            return np.tile(self._points[0], (n, 1)).astype(np.float32)

        positions = np.linspace(0.0, self._total_perimeter, n, endpoint=False)
        out = np.empty((n, 2), dtype=np.float32)

        for i, pos in enumerate(positions):
            segment_idx = int(np.searchsorted(self._cumulative_lengths[1:], pos))
            if segment_idx >= self._n:
                segment_idx = self._n - 1

            seg_len = self._segment_lengths[segment_idx]
            seg_start = self._cumulative_lengths[segment_idx]
            t = 0.0 if seg_len <= 1e-12 else (pos - seg_start) / seg_len
            t = float(np.clip(t, 0.0, 1.0))

            p1 = self._points[segment_idx]
            p2 = self._points[(segment_idx + 1) % self._n]
            out[i] = p1 + t * (p2 - p1)

        return out

    def area(self) -> np.float32:
        p = self._points
        x = p[:, 0]
        y = p[:, 1]
        a = 0.5 * np.abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
        return np.float32(a)


class Assignment5:
    def __init__(self):
        pass

    def area(self, contour: callable, maxerr=0.001) -> np.float32:
        prev = None
        n = 128
        for _ in range(8):
            pts = contour(n)
            x = pts[:, 0]
            y = pts[:, 1]
            a = 0.5 * np.abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
            if prev is not None and abs(a - prev) < maxerr:
                return np.float32(a)
            prev = a
            n *= 2
        return np.float32(prev if prev is not None else 0.0)

    @staticmethod
    def _convex_hull(points):
        pts = np.asarray(points, dtype=np.float32)
        if len(pts) < 3:
            return pts

        order = np.lexsort((pts[:, 1], pts[:, 0]))
        pts = pts[order]

        def cross(o, a, b):
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

        lower = []
        for p in pts:
            while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
                lower.pop()
            lower.append(p)

        upper = []
        for p in pts[::-1]:
            while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
                upper.pop()
            upper.append(p)

        return np.vstack((lower[:-1], upper[:-1])).astype(np.float32)

    @staticmethod
    def _smooth_cyclic(points, alpha=0.12):
        p = np.asarray(points, dtype=np.float32)
        if len(p) < 5 or alpha <= 0:
            return p
        return ((1 - 2 * alpha) * p +
                alpha * np.roll(p, 1, axis=0) +
                alpha * np.roll(p, -1, axis=0)).astype(np.float32)

    def fit_shape(self, sample: callable, maxtime: float) -> AbstractShape:
        start = time.time()
        end_by = start + max(0.0, maxtime - 1.2)

        pts = []
        cap = 120000
        while len(pts) < cap and time.time() < end_by:
            try:
                x, y = sample()
            except:
                break
            if np.isfinite(x) and np.isfinite(y):
                pts.append((x, y))

        if len(pts) < 3:
            return MyShape([[0, 0], [1, 0], [0.5, 1]])

        P = np.array(pts, dtype=np.float32)

        def trim_by_radius(P, c, lo_p=2, hi_p=98):
            d = np.linalg.norm(P - c, axis=1)
            lo = np.percentile(d, lo_p)
            hi = np.percentile(d, hi_p)
            m = (d >= lo) & (d <= hi)
            return P[m] if np.sum(m) >= 3 else P

        c = np.median(P, axis=0)
        P = trim_by_radius(P, c, 2, 98)
        c = np.median(P, axis=0)
        P = trim_by_radius(P, c, 2, 98)

        if time.time() >= end_by or len(P) < 20:
            hull = self._convex_hull(P)
            return MyShape(hull if len(hull) >= 3 else P[:3])

        v = P - c
        r = np.linalg.norm(v, axis=1)
        ang = (np.arctan2(v[:, 1], v[:, 0]) + 2.0 * np.pi) % (2.0 * np.pi)

        r_med = float(np.median(r))
        mad = float(np.median(np.abs(r - r_med)) + 1e-9)
        circ_score = mad / (r_med + 1e-9)

        if circ_score < 0.06 and time.time() < end_by:
            N = 360
            t = np.linspace(0.0, 2.0 * np.pi, N, endpoint=False).astype(np.float32)
            circle = np.stack([c[0] + r_med * np.cos(t), c[1] + r_med * np.sin(t)], axis=1)
            return MyShape(circle.astype(np.float32))

        n = len(P)
        bins = 512
        if n < 4000:
            bins = 360
        if n < 1200:
            bins = 240
        if n > 20000:
            bins = 720

        idx = np.floor(ang / (2.0 * np.pi) * bins).astype(np.int32)
        idx = np.clip(idx, 0, bins - 1)

        order = np.argsort(idx)
        idx_s = idx[order]
        v_s = v[order]
        r_s = r[order]

        contour = np.full((bins, 2), np.nan, dtype=np.float32)
        filled = np.zeros(bins, dtype=bool)

        i = 0
        while i < len(idx_s) and time.time() < end_by:
            j = i + 1
            while j < len(idx_s) and idx_s[j] == idx_s[i]:
                j += 1
            b = int(idx_s[i])
            if j - i >= 3:
                vv = v_s[i:j]
                rr = r_s[i:j]
                uu = vv / (np.linalg.norm(vv, axis=1)[:, None] + 1e-9)
                dvec = np.median(uu, axis=0)
                dn = float(np.linalg.norm(dvec))
                if dn > 1e-9:
                    rad = float(np.median(rr))
                    contour[b] = c + (rad * (dvec / dn)).astype(np.float32)
                    filled[b] = True
            i = j

        if np.sum(filled) < 40:
            hull = self._convex_hull(P)
            hull = self._smooth_cyclic(hull, 0.08) if len(hull) >= 5 else hull
            return MyShape(hull if len(hull) >= 3 else P[:3])

        x = contour[:, 0]
        y = contour[:, 1]
        valid = filled.copy()

        def fill_cyclic(arr, valid):
            n = len(arr)
            out = arr.copy()
            if np.all(valid):
                return out, valid
            idxs = np.where(valid)[0]
            for k in range(len(idxs)):
                a = idxs[k]
                b = idxs[(k + 1) % len(idxs)]
                if b == a:
                    continue
                if b > a:
                    gap = b - a - 1
                    if gap > 0:
                        for t in range(1, gap + 1):
                            out[a + t] = out[a] * (1 - t / (gap + 1)) + out[b] * (t / (gap + 1))
                            valid[a + t] = True
                else:
                    gap = (n - a - 1) + b
                    if gap > 0:
                        for t in range(1, gap + 1):
                            pos = (a + t) % n
                            out[pos] = out[a] * (1 - t / (gap + 1)) + out[b] * (t / (gap + 1))
                            valid[pos] = True
            return out, valid

        x, valid = fill_cyclic(x, valid)
        y, valid = fill_cyclic(y, valid)
        contour = np.stack([x, y], axis=1).astype(np.float32)

        contour = self._smooth_cyclic(contour, 0.10)

        if len(contour) > 480:
            contour = contour[np.linspace(0, len(contour) - 1, 480, dtype=np.int32)]

        return MyShape(contour.astype(np.float32))

    
    def __init__(self):
        pass

    def area(self, contour: callable, maxerr=0.001) -> np.float32:
        # Faster convergence: geometric refinement
        prev = None
        n = 128
        for _ in range(8):  # 128 -> 16384 max
            pts = contour(n)
            x = pts[:, 0]
            y = pts[:, 1]
            a = 0.5 * np.abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
            if prev is not None and abs(a - prev) < maxerr:
                return np.float32(a)
            prev = a
            n *= 2
        return np.float32(prev if prev is not None else 0.0)

    # ---------- helpers ----------
    @staticmethod
    def _convex_hull(points: np.ndarray) -> np.ndarray:
        """
        Monotonic chain convex hull. O(n log n).
        Returns hull points in CCW order without repeating first point.
        """
        pts = np.asarray(points, dtype=np.float32)
        if len(pts) < 3:
            return pts

        # sort by (x, y)
        order = np.lexsort((pts[:, 1], pts[:, 0]))
        pts = pts[order]

        def cross(o, a, b):
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

        lower = []
        for p in pts:
            while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
                lower.pop()
            lower.append(p)

        upper = []
        for p in pts[::-1]:
            while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
                upper.pop()
            upper.append(p)

        hull = np.vstack((lower[:-1], upper[:-1]))
        return hull.astype(np.float32)

    @staticmethod
    def _smooth_cyclic(points: np.ndarray, alpha: float = 0.12) -> np.ndarray:
        """
        Very light cyclic smoothing: p[i] = (1-2a)p[i] + a p[i-1] + a p[i+1]
        """
        p = np.asarray(points, dtype=np.float32)
        if len(p) < 5 or alpha <= 0:
            return p
        prev = np.roll(p, 1, axis=0)
        nxt = np.roll(p, -1, axis=0)
        return ((1.0 - 2.0 * alpha) * p + alpha * prev + alpha * nxt).astype(np.float32)

    def fit_shape(self, sample: callable, maxtime: float) -> AbstractShape:
        start = time.time()

        # Hard-ish guard: leave time for any last processing & return
        end_by = start + max(0.0, maxtime - 1.2)

        # --------- Phase 1: sample points ----------
        pts = []
        # sample until time or cap
        cap = 60000  # high enough for stable medians, low enough to be fast
        while len(pts) < cap and time.time() < end_by:
            try:
                x, y = sample()
            except Exception:
                break
            if np.isfinite(x) and np.isfinite(y):
                pts.append((x, y))

        if len(pts) < 3:
            return MyShape(np.array([[0, 0], [1, 0], [0.5, 1]], dtype=np.float32))

        P = np.array(pts, dtype=np.float32)

        # --------- Phase 2: robust trimming ----------
        # robust center: coordinate-wise median
        c = np.median(P, axis=0)
        d = np.linalg.norm(P - c, axis=1)

        # Keep central mass of radial distances (robust to outliers)
        # 5%..95% is usually great for noisy circles & general shapes
        lo = np.percentile(d, 5)
        hi = np.percentile(d, 95)
        mask = (d >= lo) & (d <= hi)
        if np.sum(mask) >= 3:
            P = P[mask]
            d = d[mask]

        # If time is super tight, bail with a hull
        if time.time() >= end_by or len(P) < 8:
            hull = self._convex_hull(P)
            if len(hull) >= 3:
                return MyShape(hull)
            return MyShape(P[:3])

        # --------- Phase 3: angle binning + radial median ----------
        # Use bins to reconstruct a clean contour even under noise.
        # Choose bins based on time and data size.
        # (More bins => better shape, but more work)
        n = len(P)
        # 128-512 is a good range; circles get very accurate here.
        bins = 256
        if n < 2000:
            bins = 160
        if n < 800:
            bins = 128
        if n > 15000:
            bins = 320

        v = P - c
        ang = np.arctan2(v[:, 1], v[:, 0])  # [-pi, pi]
        # map to [0, 2pi)
        ang = (ang + 2.0 * np.pi) % (2.0 * np.pi)

        # bin indices
        idx = np.floor(ang / (2.0 * np.pi) * bins).astype(np.int32)
        idx = np.clip(idx, 0, bins - 1)

        # For each bin, take median radius and median direction
        # We'll compute a stable point on that direction with median radius.
        # Efficient grouping using sorting.
        order = np.argsort(idx)
        idx_s = idx[order]
        v_s = v[order]
        r_s = np.linalg.norm(v_s, axis=1)

        contour = []
        i = 0
        while i < len(idx_s) and time.time() < end_by:
            j = i + 1
            while j < len(idx_s) and idx_s[j] == idx_s[i]:
                j += 1

            # if bin has enough points, use it
            if j - i >= 4:
                vv = v_s[i:j]
                rr = r_s[i:j]
                # direction: median of normalized vectors
                norms = np.linalg.norm(vv, axis=1) + 1e-9
                uu = vv / norms[:, None]
                dir_vec = np.median(uu, axis=0)
                dn = float(np.linalg.norm(dir_vec))
                if dn > 1e-9:
                    dir_vec = dir_vec / dn
                    rad = float(np.median(rr))
                    contour.append(c + rad * dir_vec)

            i = j

        contour = np.array(contour, dtype=np.float32)

        # If angle binning produced too few points (e.g., weird sampler),
        # fall back to convex hull.
        if len(contour) < 20:
            hull = self._convex_hull(P)
            if len(hull) >= 3:
                hull = self._smooth_cyclic(hull, alpha=0.08)
                return MyShape(hull)
            return MyShape(P[:3])

        # --------- Phase 4: order + light smoothing ----------
        cc = np.mean(contour, axis=0)
        a2 = np.arctan2(contour[:, 1] - cc[1], contour[:, 0] - cc[0])
        contour = contour[np.argsort(a2)]

        # remove near-duplicates
        if len(contour) > 3:
            keep = [0]
            for k in range(1, len(contour)):
                if np.linalg.norm(contour[k] - contour[keep[-1]]) > 1e-3:
                    keep.append(k)
            contour = contour[keep]

        contour = self._smooth_cyclic(contour, alpha=0.10)

        # Cap points (faster sampling + area), but keep enough detail
        if len(contour) > 400:
            take = np.linspace(0, len(contour) - 1, 400, dtype=np.int32)
            contour = contour[take]

        if len(contour) < 3:
            contour = self._convex_hull(P)
            if len(contour) < 3:
                contour = P[:3]

        return MyShape(contour.astype(np.float32))

    def __init__(self):
        """
        Here goes any one time calculation that need to be made before 
        solving the assignment for specific functions. 
        """
        pass

    def area(self, contour: callable, maxerr=0.001) -> np.float32:
        """
        Compute the area of the shape with the given contour. 

        Parameters
        ----------
        contour : callable
            Same as AbstractShape.contour 
        maxerr : TYPE, optional
            The target error of the area computation. The default is 0.001.

        Returns
        -------
        The area of the shape.
        """
        # Adaptive approach: start with fewer points and increase until error stabilizes
        prev_area = None
        n = 100  # Start with 100 points
        
        while n <= 10000:
            # Get contour points
            points = contour(n)
            
            # Calculate area using Shoelace formula
            x = points[:, 0]
            y = points[:, 1]
            area = 0.5 * np.abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
            
            # Check convergence
            if prev_area is not None:
                error = abs(area - prev_area)
                if error < maxerr:
                    return np.float32(area)
            
            prev_area = area
            
            # If we've reached the maximum, return the result
            if n >= 10000:
                return np.float32(area)
            
            # Increase number of points
            if n < 1000:
                n *= 2
            else:
                n += 1000
            
            # Cap at 10000
            if n > 10000:
                n = 10000
        
        return np.float32(area)
    
    def fit_shape(self, sample: callable, maxtime: float) -> AbstractShape:
        """
        Build a function that accurately fits the noisy data points sampled from
        some closed shape. 
        
        Parameters
        ----------
        sample : callable. 
            An iterable which returns a data point that is near the shape contour.
        maxtime : float
            This function returns after at most maxtime seconds. 

        Returns
        -------
        An object extending AbstractShape. 
        """
        start_time = time.time()
        safety_margin = 1.5
        time_budget = maxtime - safety_margin
        
        if time_budget < 1.0:
            time_budget = 1.0
        
        # Phase 1: Collect samples
        samples = []
        sample_time_budget = time_budget * 0.85
        sample_count = 0
        max_samples = 100000
        
        sampling_end_time = start_time + sample_time_budget
        
        while time.time() < sampling_end_time and sample_count < max_samples:
            try:
                if time.time() >= start_time + maxtime - safety_margin:
                    break
                    
                x, y = sample()
                if np.isfinite(x) and np.isfinite(y):
                    samples.append([x, y])
                    sample_count += 1
                    
                if time.time() >= sampling_end_time:
                    break
            except:
                break
        
        # Emergency exit
        if time.time() >= start_time + maxtime - 1.2 or len(samples) < 3:
            if len(samples) >= 3:
                return MyShape(np.array(samples[:3], dtype=np.float32))
            return MyShape(np.array([[0, 0], [1, 0], [0.5, 1]], dtype=np.float32))
        
        if len(samples) < 3:
            return MyShape(np.array([[0, 0], [1, 0], [0.5, 1]], dtype=np.float32))
        
        samples = np.array(samples, dtype=np.float32)
        
        # Phase 2: Very conservative outlier removal
        try:
            # Use percentile-based filtering - keep 98% of points
            median = np.median(samples, axis=0)
            distances = np.linalg.norm(samples - median, axis=1)
            threshold = np.percentile(distances, 98)
            mask = distances <= threshold
            if np.sum(mask) >= 3:
                samples = samples[mask]
        except:
            pass
        
        if len(samples) < 3:
            return MyShape(np.array([[0, 0], [1, 0], [0.5, 1]], dtype=np.float32))
        
        # Phase 3: Order points by angle from centroid
        try:
            centroid = np.mean(samples, axis=0)
            angles = np.arctan2(samples[:, 1] - centroid[1], 
                               samples[:, 0] - centroid[0])
            sorted_indices = np.argsort(angles)
            ordered_samples = samples[sorted_indices]
        except:
            ordered_samples = samples
        
        # Phase 4: Intelligent decimation
        n_samples = len(ordered_samples)
        
        # Keep MORE points - the previous approach was over-decimating
        if n_samples < 100:
            # Few samples - keep almost all
            n_target = max(10, int(n_samples * 0.9))
        elif n_samples < 1000:
            # Medium - keep at least 20%
            n_target = max(50, int(n_samples * 0.2))
        elif n_samples < 5000:
            # Many - keep 15%
            n_target = max(100, int(n_samples * 0.15))
        else:
            # Very many - keep 10% but cap at 200
            n_target = min(200, max(150, int(n_samples * 0.1)))
        
        try:
            if len(ordered_samples) > n_target:
                indices = np.linspace(0, len(ordered_samples) - 1, n_target, dtype=int)
                indices = np.unique(indices)
                simplified_contour = ordered_samples[indices]
            else:
                simplified_contour = ordered_samples
        except:
            simplified_contour = ordered_samples[:n_target] if len(ordered_samples) > n_target else ordered_samples
        
        # Phase 5: MINIMAL smoothing - preserve sharp features
        if time.time() < start_time + maxtime - 0.5 and len(simplified_contour) >= 5:
            try:
                # Very light 3-point smoothing only
                smoothed = np.copy(simplified_contour)
                
                for i in range(len(simplified_contour)):
                    prev_idx = (i - 1) % len(simplified_contour)
                    next_idx = (i + 1) % len(simplified_contour)
                    
                    # Weighted average: 70% current, 15% each neighbor
                    smoothed[i] = (0.7 * simplified_contour[i] + 
                                  0.15 * simplified_contour[prev_idx] + 
                                  0.15 * simplified_contour[next_idx])
                
                simplified_contour = smoothed
            except:
                pass
        
        return MyShape(simplified_contour.astype(np.float32))


##########################################################################


import unittest
from sampleFunctions import *

try:
    from tqdm import tqdm
except ImportError:
    # Fallback if tqdm is not available
    def tqdm(iterable, **kwargs):
        return iterable


class TestAssignment5(unittest.TestCase):

    def test_return(self):
        circ = noisy_circle(cx=1, cy=1, radius=1, noise=0.1)
        ass5 = Assignment5()
        T = time.time()
        shape = ass5.fit_shape(sample=circ, maxtime=5)
        T = time.time() - T
        self.assertTrue(isinstance(shape, AbstractShape))
        self.assertLessEqual(T, 7)  # Allow 2 second buffer

    def test_delay(self):
        circ = noisy_circle(cx=1, cy=1, radius=1, noise=0.1)

        def sample():
            time.sleep(7)
            return circ()

        ass5 = Assignment5()
        T = time.time()
        shape = ass5.fit_shape(sample=sample, maxtime=5)
        T = time.time() - T
        self.assertTrue(isinstance(shape, AbstractShape))
        self.assertGreaterEqual(T, 5)

    def test_circle_area(self):
        circ = noisy_circle(cx=1, cy=1, radius=1, noise=0.1)
        ass5 = Assignment5()
        T = time.time()
        shape = ass5.fit_shape(sample=circ, maxtime=30)
        T = time.time() - T
        a = shape.area()
        self.assertLess(abs(a - np.pi), 0.01)
        self.assertLessEqual(T, 32)

    def test_bezier_fit(self):
        circ = noisy_circle(cx=1, cy=1, radius=1, noise=0.1)
        ass5 = Assignment5()
        T = time.time()
        shape = ass5.fit_shape(sample=circ, maxtime=30)
        T = time.time() - T
        a = shape.area()
        self.assertLess(abs(a - np.pi), 0.01)
        self.assertLessEqual(T, 32)


if __name__ == "__main__":
    unittest.main()